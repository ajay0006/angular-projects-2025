import { Component } from '@angular/core';
import { ProductsComponent } from './product/product.component';
import { DataService } from './services/data.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [CommonModule, ProductsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'my-first-app';
  message = '';

  constructor(private readonly dataService: DataService) {}

  showEnvironment() {
    this.message = this.dataService.getMessage();
  }
}
