import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { DataService } from './services/data.service';
import { DevDataService } from './services/dev-data.service';
import { ProdDataService } from './services/prod-data.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    { provide: DataService, useClass: DevDataService },
  ],
};
