export class ProductModel {
  productId!: number;
  productName!: string;
  stock!: number;
}
