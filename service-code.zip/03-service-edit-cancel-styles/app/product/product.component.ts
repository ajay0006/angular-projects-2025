import { Component } from '@angular/core';
import { ProductsService } from '../products.service';
import { FormsModule } from '@angular/forms';
import { ProductModel } from '../models/product.model';

@Component({
  selector: 'app-product',
  imports: [FormsModule],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css',
})
export class ProductsComponent {
  productModel: ProductModel;
  editingProductId: number | null = null;
  editModel: ProductModel | null = null;

  // use the constructor to inject the service,  or use the following:
  // productSvc: ProductService = inject(ProductService)
  constructor(private readonly productsSvc: ProductsService) {
    this.productModel = new ProductModel();
  }

  getProducts() {
    return this.productsSvc.getProducts(); // pass-through
  }

  addProduct() {
    this.productsSvc.addProduct(this.productModel);
    this.productModel = new ProductModel();
  }

  startEdit(product: ProductModel) {
    this.editingProductId = product.productId;
    this.editModel = { ...product };
  }

  cancelEdit() {
    this.editingProductId = null;
    this.editModel = null;
  }

  saveEdit() {
    if (!this.editModel) return;
    this.productsSvc.updateProduct(this.editModel);
    this.cancelEdit();
  }

  deleteProduct(productId: number) {
    this.productsSvc.deleteProduct(productId);
    if (this.editingProductId === productId) {
      this.cancelEdit();
    }
  }
}
