import { TestBed } from '@angular/core/testing';

import { ProductsService } from './products.service';

describe('ProductService', () => {
  let service: ProductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
