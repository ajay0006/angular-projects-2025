import { Injectable } from '@angular/core';

/* Use this syntax to provide the service at root level */
@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  products = [
    {
      productId: 1,
      productName: 'Laptop',
      stock: 25,
    },
    {
      productId: 2,
      productName: 'Smartphone',
      stock: 50,
    },
  ];

  getProducts() {
    return this.products;
  }

  addProduct(product: any) {
    this.products.push(product);
  }

  updateProduct(updated: {
    productId: number;
    productName: string;
    stock: number;
  }) {
    const idx = this.products.findIndex(
      (p) => p.productId === updated.productId
    );
    if (idx !== -1) {
      this.products[idx] = { ...this.products[idx], ...updated };
    }
  }

  deleteProduct(productId: number) {
    const idx = this.products.findIndex((p) => p.productId === productId);
    if (idx !== -1) {
      this.products.splice(idx, 1);
    }
  }
}
