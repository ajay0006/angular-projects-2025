export abstract class DataService {
  abstract getMessage(): string;
}
