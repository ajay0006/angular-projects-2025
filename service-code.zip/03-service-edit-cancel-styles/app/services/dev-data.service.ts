import { Injectable } from '@angular/core';
import { DataService } from './data.service';

@Injectable({ providedIn: 'root' })
export class DevDataService implements DataService {
  getMessage(): string {
    return 'Dev environment';
  }
}
