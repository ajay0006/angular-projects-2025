import { Injectable } from '@angular/core';
import { DataService } from './data.service';

@Injectable({ providedIn: 'root' })
export class ProdDataService implements DataService {
  getMessage(): string {
    return 'Prod environment';
  }
}
